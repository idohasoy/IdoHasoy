﻿-- CUSTOMERS TABLE
CREATE TABLE CUSTOMERS(
Email VARCHAR(50) NOT NULL,
First_Name VARCHAR(20) NOT NULL,
Last_Name VARCHAR(20) NOT NULL,
Company_Name VARCHAR(20) NOT NULL,
Company_URL VARCHAR(100) NOT NULL,
Company_Address VARCHAR (50) NOT NULL,
Line_2 VARCHAR(50) NULL,
City VARCHAR(50) NOT NULL,
[State] VARCHAR(50) NOT NULL,
ZIP Char(5) NOT NULL,
About_Us VARCHAR(50) NOT NULL,
Phone Char(10) NOT NULL

CONSTRAINT PK_CUSTOMERS PRIMARY KEY (Email),
CONSTRAINT CK_SSN_EMAIL_CUSTOMER CHECK (Email LIKE '%@%.%'),
CONSTRAINT CK_PHONE_CUSTOMER CHECK (Phone LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
CONSTRAINT CK_SSN_ZIP_CUSTOMER CHECK (ZIP LIKE '[0-9][0-9][0-9][0-9][0-9]'),
CONSTRAINT AK_PHONE_CUSTOMER UNIQUE(Phone)
);

-- BAGS TABLE
CREATE TABLE BAGS(
[Type] VARCHAR(50) NOT NULL,
Category VARCHAR(50) NOT NULL,

CONSTRAINT PK_BAGS PRIMARY KEY ([Type])
);

-- STYLES Tables
CREATE TABLE STYLES(
StyleID int NOT NULL,
[Type] VARCHAR(50) NOT NULL,
Lining_Liner VARCHAR(100)  NULL, 
Lining_Color VARCHAR(50)  NULL,
Cording VARCHAR(20) NOT NULL ,
Thread_Color SMALLINT NOT NULL, 
Strap_Material VARCHAR(100) NULL,
Strap_Color VARCHAR(50) NULL, 

CONSTRAINT PK_styleID PRIMARY KEY(StyleID, [Type]),
CONSTRAINT FK_TYPE_BAGS FOREIGN KEY ([Type]) REFERENCES BAGS([Type])
);

-- ORDERS TABLE
CREATE TABLE ORDERS(
OrderID int identity(1,1) NOT NULL,
Quantity int NOT NULL,
Ordered_By VARCHAR (50) NOT NULL,
[Type] VARCHAR(50) NOT NULL, 
StyleID int NOT NULL,
Order_Date Date NOT NULL

CONSTRAINT PK_ORDERS PRIMARY KEY (OrderID),
CONSTRAINT FK_ORDERED_BY_CUSTOMER FOREIGN KEY (Ordered_By) REFERENCES CUSTOMERS (Email),
CONSTRAINT FK_TYPE_STYLEID_ORDERS FOREIGN KEY (StyleID, [Type]) REFERENCES STYLES(StyleID, [Type]),
CONSTRAINT CK_QUANTITY_100 CHECK (Quantity>=100)
);

-- DECORATIONS LOCATIONS TABLE
CREATE TABLE DECORATIONS_LOCATIONS (
[Location] VARCHAR(50) NOT NULL,
StyleID int NOT NULL,
[Type] VARCHAR(50) NOT NULL

CONSTRAINT PK_DECORATIONS_LOCTAIONS PRIMARY KEY ([Location], StyleID, [Type]),
CONSTRAINT FK_STYLEID_TYPE_DECORATIONS_LOCATIONS FOREIGN KEY (StyleID, [Type]) REFERENCES STYLES(StyleID, [Type]),
);

-- DECORATIONS INSTRUCTIONS TABLE
CREATE TABLE DECORATIONS_INSTRUCTIONS (
Instruction VARCHAR(50) NOT NULL,
StyleID int NOT NULL,
[Type] VARCHAR(50) NOT NULL

CONSTRAINT PK_DECORATIONS_INSTRUCTIONS PRIMARY KEY (Instruction, StyleID, [Type]),
CONSTRAINT FK_STYLEID_TYPE_DECORATIONS_INSTRUCTIONS FOREIGN KEY (StyleID, [Type]) REFERENCES STYLES(StyleID, [Type]),
);

-- FABRIC TABLE
CREATE TABLE FABRICS(
StyleID int NOT NULL,
[Type] VARCHAR(50) NOT NULL,
Material_Type VARCHAR(50) NOT NULL,
Color VARCHAR(50) NOT NULL

CONSTRAINT PK_FABRICS PRIMARY KEY(Material_Type, Color, StyleID, [Type]),
CONSTRAINT FK_STYLEID_TYPE_FABRICS FOREIGN KEY (StyleID, [Type]) REFERENCES STYLES(StyleID, [Type]),
);

-- LookUps Tables
-- state lookup table
CREATE TABLE States(
[State]VARCHAR(50) NOT NULL
CONSTRAINT PK_STATE PRIMARY KEY ([State])
);
ALTER TABLE CUSTOMERS
ADD CONSTRAINT FK_Customers_State FOREIGN KEY([State]) REFERENCES States([State]);


-- type (bags) lookup table
CREATE TABLE [Types](
[Type] VARCHAR(50) NOT NULL
CONSTRAINT PK_TYPES PRIMARY KEY ([Type])
);
ALTER TABLE BAGS
ADD CONSTRAINT FK_Type_Of_Bag FOREIGN KEY([Type]) REFERENCES [Types]([Type]);


-- category (bags) lookup table
CREATE TABLE Categories(
Category VARCHAR(50) NOT NULL
CONSTRAINT PK_Category PRIMARY KEY (Category)
);
ALTER TABLE BAGS
ADD CONSTRAINT FK_Category_Of_Bag FOREIGN KEY(Category) REFERENCES Categories(Category);


-- Lining Liners (Styles) Table 
CREATE TABLE Lining_Liners(
Lining_Liner VARCHAR(100) NOT NULL
CONSTRAINT PK_LINING_LINERS PRIMARY KEY (Lining_Liner)
);
ALTER TABLE STYLES
ADD CONSTRAINT FK_Lining_Liner_Of_Style FOREIGN KEY(Lining_Liner) REFERENCES Lining_Liners(Lining_Liner);


-- Cordings (Styles) lookup table
CREATE TABLE Cordings(
Cording VARCHAR(20) NOT NULL
CONSTRAINT PK_CORDINGS PRIMARY KEY (Cording)
);
ALTER TABLE STYLES
ADD CONSTRAINT FK_Cording_Of_Styles FOREIGN KEY(Cording) REFERENCES Cordings(Cording);



-- Threads Colors (Styles) lookup table
CREATE TABLE Threads_Colors(
Thread_Color SMALLINT NOT NULL
CONSTRAINT PK_THREAD_COLOR PRIMARY KEY (Thread_Color)
);
ALTER TABLE STYLES
ADD CONSTRAINT FK_Threads_Colors_Of_Styles FOREIGN KEY(Thread_Color) REFERENCES Threads_Colors(Thread_Color);


-- Locations (Decoreations Locations) lookup table
CREATE TABLE Locations(
[Location] VARCHAR(50) NOT NULL
CONSTRAINT PK_LOCATIONS PRIMARY KEY ([Location])
);
ALTER TABLE DECORATIONS_LOCATIONS
ADD CONSTRAINT FK_Location_Of_Decoration_Location FOREIGN KEY([Location]) REFERENCES Locations([Location]);


-- Instructions (Decoreations Instructions) lookup table
CREATE TABLE Instuctions(
Instruction VARCHAR(50) NOT NULL
CONSTRAINT PK_INSTRUCTIONS PRIMARY KEY (Instruction)
);
ALTER TABLE DECORATIONS_INSTRUCTIONS
ADD CONSTRAINT FK_Instruction_Of_Decoration_Instructions FOREIGN KEY(Instruction) REFERENCES Instuctions(Instruction);


-- Materials_Straps (STRAPS) lookup table
CREATE TABLE Materials_Straps(
Material_Strap VARCHAR(100) NOT NULL
CONSTRAINT PK_MATERIALS_STRAPS PRIMARY KEY (Material_Strap)
);
ALTER TABLE STYLES
ADD CONSTRAINT FK_Material_Of_Strap FOREIGN KEY(Strap_Material) REFERENCES Materials_Straps(Material_Strap);

-- Colors (STRAPS) and (FABRICS) lookup table
CREATE TABLE Colors(
Color VARCHAR(50) NOT NULL
CONSTRAINT PK_COLORS PRIMARY KEY (Color)
);
ALTER TABLE STYLES
ADD CONSTRAINT FK_Color_Of_Strap FOREIGN KEY(Strap_Color) REFERENCES Colors(Color);
ALTER TABLE FABRICS
ADD CONSTRAINT FK_Color_Of_Fabric FOREIGN KEY(Color) REFERENCES Colors(Color);
ALTER TABLE STYLES
ADD CONSTRAINT FK_Color_Of_Lining FOREIGN KEY(Lining_Color) REFERENCES Colors(Color);


-- Materials_Types (FABRICS) lookup table
CREATE TABLE Materials_Types(
Material_Type VARCHAR(50) NOT NULL
CONSTRAINT PK_MATERIALS_TYPES PRIMARY KEY (Material_Type)
);
ALTER TABLE FABRICS
ADD CONSTRAINT FK_Material_Type_Of_Fabric FOREIGN KEY(Material_Type) REFERENCES Materials_Types(Material_Type);





-- Queries --


-- show list of 3 colors of straps that most ordered by customers in first median of 2023
-- The output should be color of strap and quantity of orders
SELECT TOP 3 Strap_Color, COUNT (Strap_Color) as [Number Of Straps]
FROM CUSTOMERS AS C JOIN ORDERS AS O ON C.Email = O.Ordered_By
JOIN STYLES AS S ON O.[Type] = S.Type AND O.StyleID = S.StyleID
WHERE YEAR (O.Order_Date) = 2023 AND MONTH (O.Order_Date) IN (1,2,3,4,5,6)
GROUP BY S.Strap_Color
ORDER BY COUNT (Strap_Color) DESC


-- show companies which their avarage orders of bags from category "Backpack" were more then 1000
-- the ouput should be name of company, phone, and avarage ordered bags
SELECT DISTINCT C.Company_Name, C.Phone, AVG(O.Quantity) AS [Avarage Quantity]
FROM CUSTOMERS AS C JOIN ORDERS AS O ON C.Email = O.Ordered_By
JOIN STYLES AS S ON O.[Type] = S.Type AND O.StyleID = S.StyleID
JOIN BAGS AS B ON S.[Type] = B.[Type]
WHERE B.Category = 'Backpack'
GROUP BY C.Company_Name, C.Phone
HAVING AVG(O.Quantity) > 1000

-- return utilization of orders from every state and precent of orders from total orders
SELECT C.State ,Utilistaion = ROUND((cast(SUM(O.Quantity) AS float) / CAST((SELECT SUM(Quantity)FROM ORDERS) AS FLOAT))*100 ,2)
FROM ORDERS AS O JOIN CUSTOMERS AS C ON C.Email = O.Ordered_By
GROUP BY C.State
Order by Utilistaion DESC

-- return list of customers which ordered following types of bags :
--'Laptop Bag', 'Computer Backpack'
-- The output should be - company name and phone
SELECT C.Company_Name,C.Phone
FROM CUSTOMERS C
WHERE C.Email IN (
	SELECT O1.Ordered_By
	FROM ORDERS O1
    WHERE O1.Type = 'Laptop Bag' AND O1.Ordered_By IN (
		SELECT O2.Ordered_By
        FROM ORDERS O2
		WHERE O2.Type = 'Computer Backpack'
            )
    );


-- Delete Customers who didnt bought in the past 10 years
WITH CustomerLastOrder as( 
SELECT O.Ordered_By , LAST_ORDER = MAX(O.Order_Date)  FROM ORDERS AS O
GROUP BY O.Ordered_By
)
DELETE FROM CUSTOMERS 
WHERE Email IN (SELECT Ordered_By FROM CustomerLastOrder WHERE YEAR(GETDATE()) - YEAR(LAST_ORDER) > 10)

-- show change in number of orders from current year to previous year
WITH 
totalOrdersByYear AS (
SELECT Year(Order_Date) AS [Year],count(Ordered_By) AS totalOrders  FROM ORDERS
GROUP BY Year(Order_Date)
)
SELECT T.[Year],
diff_From_Previous = T.totalOrders - lAG(T.totalOrders) OVER (ORDER BY [Year]),
diff_from_firstYear =T.totalOrders - FIRST_VALUE(T.totalOrders) OVER (ORDER BY T.[YEAR])
FROM totalOrdersByYear AS T


-- show types of bags which ordered in New York but not in Miami
WITH
Ordered_In_NEWYORK AS (
SELECT DISTINCT O.Type
FROM ORDERS AS O JOIN CUSTOMERS AS C ON C.Email = O.Ordered_By
WHERE C.State = 'New York' 
),
Ordered_In_Miami AS (
SELECT DISTINCT O.Type
FROM ORDERS AS O JOIN CUSTOMERS AS C ON C.Email = O.Ordered_By
WHERE C.State = 'Miami'
)
SELECT Ordered_In_NEWYORK.Type 
FROM Ordered_In_NEWYORK
EXCEPT
SELECT Ordered_In_Miami.Type
FROM Ordered_In_Miami

-- show 10 customers which ordered last, their total bags, their rank relevant to other customers in relation bags amount
SELECT top 10 Customer_Email,Total_Bags, Customer_Rank, Last_Order_Date
FROM (
      SELECT CUSTOMERS.Email AS Customer_Email,
            SUM(ORDERS.Quantity) AS Total_Bags,
            RANK() OVER (ORDER BY SUM(ORDERS.Quantity) DESC) AS Customer_Rank,
            MAX(Order_Date) AS Last_Order_Date
        FROM ORDERS JOIN CUSTOMERS ON ORDERS.Ordered_By = CUSTOMERS.Email
        GROUP BY CUSTOMERS.Email
    ) AS CustomerSummary
ORDER BY Last_Order_Date DESC

-- WITH דוח לשנת 2023
--האם יש תיקים שנרכשים יותר בתקופות הבלאק פריידיי וחג המולד מאשר בחודשיים אחרים בשנה עם הכי הרבה מכירות 
WITH COUPLE_MONTHS AS (
    SELECT B.Type AS BagType,
        SUM(CASE WHEN MONTH(O.Order_Date) IN (1, 2) THEN 1 ELSE 0 END) AS Jan_Feb,
        SUM(CASE WHEN MONTH(O.Order_Date) IN (3, 4) THEN 1 ELSE 0 END) AS Mar_Apr,
        SUM(CASE WHEN MONTH(O.Order_Date) IN (5, 6) THEN 1 ELSE 0 END) AS May_Jun,
        SUM(CASE WHEN MONTH(O.Order_Date) IN (7, 8) THEN 1 ELSE 0 END) AS Jul_Aug,
        SUM(CASE WHEN MONTH(O.Order_Date) IN (9, 10) THEN 1 ELSE 0 END) AS Sep_Oct,
        SUM(CASE WHEN MONTH(O.Order_Date) IN (11, 12) THEN 1 ELSE 0 END) AS Nov_Dec
    FROM BAGS B
    LEFT JOIN STYLES S ON B.Type = S.Type
    LEFT JOIN ORDERS O ON S.StyleID = O.StyleID
	WHERE YEAR(O.Order_Date)=2023
    GROUP BY B.Type
),

Best_Months AS (
    SELECT BagType,
           CASE
               WHEN Jan_Feb >= Mar_Apr AND Jan_Feb >= May_Jun AND Jan_Feb >= Jul_Aug AND Jan_Feb >= Sep_Oct THEN 'Jan_Feb'
               WHEN Mar_Apr >= Jan_Feb AND Mar_Apr >= May_Jun AND Mar_Apr >= Jul_Aug AND Mar_Apr >= Sep_Oct THEN 'Mar_Apr'
               WHEN May_Jun >= Jan_Feb AND May_Jun >= Mar_Apr AND May_Jun >= Jul_Aug AND May_Jun >= Sep_Oct THEN 'May_Jun'
               WHEN Jul_Aug >= Jan_Feb AND Jul_Aug >= Mar_Apr AND Jul_Aug >= May_Jun AND Jul_Aug >= Sep_Oct THEN 'Jul_Aug'
               ELSE 'Sep_Oct'
           END AS Best_2_Months
    FROM COUPLE_MONTHS
),

total_orders_per_bag AS (
SELECT Type, total_orders= COUNT(Ordered_By)
FROM ORDERS
GROUP BY Type),

Percent_Calculator AS (
SELECT	C.BagType,
			CASE
           WHEN B.Best_2_Months = 'Jan_Feb' THEN C.Jan_Feb
           WHEN B.Best_2_Months = 'Mar_Apr' THEN C.Mar_Apr
           WHEN B.Best_2_Months = 'May_Jun' THEN C.May_Jun
           WHEN B.Best_2_Months = 'Jul_Aug' THEN C.Jul_Aug
           ELSE C.Sep_Oct
       END AS Amount
	   FROM COUPLE_MONTHS C JOIN Best_Months B ON C.BagType = B.BagType )


SELECT C.BagType,
       C.Nov_Dec,
       B.Best_2_Months,
       CASE
           WHEN B.Best_2_Months = 'Jan_Feb' THEN C.Jan_Feb
           WHEN B.Best_2_Months = 'Mar_Apr' THEN C.Mar_Apr
           WHEN B.Best_2_Months = 'May_Jun' THEN C.May_Jun
           WHEN B.Best_2_Months = 'Jul_Aug' THEN C.Jul_Aug
           ELSE C.Sep_Oct
       END AS Amount,
	   Total_Orders_2023= T.total_orders,
	   --orders in NOV_DEC from all years in percents
	   [Nov_Dec_%]=round( cast((C.Nov_Dec) AS float)/cast((T.total_orders) AS float)*100,2),
	   --orders in NOV_DEC from all years in percents
	    [Best_2_Months_%]=round( cast((P.Amount) AS float)/cast((T.total_orders) AS float)*100,2)
FROM COUPLE_MONTHS C
JOIN Best_Months B ON C.BagType = B.BagType JOIN total_orders_per_bag AS T ON B.BagType=T.Type JOIN Percent_Calculator AS P ON T.Type=P.BagType
