import heapq
import random
import math

VOWELS = {'a', 'e', 'i', 'o', 'u'}

# Load the dictionary from the file
with open("dictionary.txt", 'r') as file:
    dictionary = set(line.strip().lower() for line in file)


def find_word_path(starting_word, goal_word, search_method, detail_output):
    """
    Find the shortest transformation path from starting_word to goal_word.
    This function performs an A* search or hill climbing to find the shortest sequence of words that
    transform from the starting word to the goal word, where each transformation is
    one character difference.

    Returns:
        list or str: The list of words forming the transformation path or 'No path found'
        if no path exists.
    """
    starting_word = starting_word.lower()
    goal_word = goal_word.lower()

    if is_word_in_dictionary(starting_word) and is_word_in_dictionary(goal_word):
        pass
    else:
        print("Invalid input: Either the starting or goal word is not in the dictionary.")
        return

    if search_method == 1:
        A_star(starting_word, goal_word, detail_output)

    elif search_method == 2:
        hill_climbing(starting_word, goal_word, 5, detail_output)
    elif search_method == 3:
        simulated_annealing(starting_word, goal_word, detail_output)
    elif search_method == 4:
        local_beam_search(starting_word,goal_word,3,detail_output)
    elif search_method == 5:
        genetic_algorithm(starting_word, goal_word,detail_output)
    else:
        raise ValueError("Only search methods 1 (A*-heuristic search) and 2 (Hill Climbing) are implemented.")


def calculate_cost(word1, word2):
    if len(word1) == len(word2):  # Substitution
        for c1, c2 in zip(word1, word2):
            if c1 != c2:
                return 0.25 if c2 in VOWELS else 1
    elif len(word1) < len(word2):  # Addition
        return 0.25 if word2[len(word1)] in VOWELS else 1
    elif len(word1) > len(word2):  # Deletion
        return 1
    return float('inf')


def heuristic(word, goal):
    """
    Heuristic function that estimates the cost to reach the goal word from the current word.
    - Adds a reward for matching characters at the same position between the word and the goal.
    - Calculates the cost for mismatched or extra characters.
    """
    differences = 0
    reward = 0
    word_len = len(word)
    goal_len = len(goal)

    # Iterate over both words and compare each character
    for i in range(min(word_len, goal_len)):
        if word[i] == goal[i]:
            reward += 0.5  # Reward for matching character (tunable value)
        else:
            # Add cost for mismatched characters
            if goal[i] in VOWELS:  # Goal character is a vowel
                differences += 0.25
            else:  # Goal character is a consonant
                differences += 1

    # Account for extra letters in either word (addition or deletion)
    if word_len < goal_len:
        for i in range(word_len, goal_len):
            if goal[i] in VOWELS:
                differences += 0.25
            else:
                differences += 1
    elif word_len > goal_len:
        for i in range(goal_len, word_len):
            if word[i] in VOWELS:
                differences += 0.25
            else:
                differences += 1

    # Incorporate the reward for matching characters
    return max(differences - reward, 0)  # Ensure heuristic remains non-negative


def adaptive_schedule(t, max_t, initial_temp=15, cooling_rate=0.8):
    """
    Adaptive exponential decay schedule for simulated annealing.
    Ensures temperature doesn't decay too quickly, promoting exploration.
    """
    if t < 0 or t > max_t:
        raise ValueError("t must be between 0 and max_t (inclusive).")

    return initial_temp * (cooling_rate ** t)


def get_neighbors(word):
    neighbors = []
    word_len = len(word)
    letters = 'abcdefghijklmnopqrstuvwxyz'

    # Substitution
    for i in range(word_len):
        for letter in letters:
            if letter != word[i]:
                new_word = word[:i] + letter + word[i + 1:]
                if new_word in dictionary:
                    neighbors.append(new_word)

    # Addition
    for i in range(word_len + 1):
        for letter in letters:
            new_word = word[:i] + letter + word[i:]
            if new_word in dictionary:
                neighbors.append(new_word)

    # Deletion
    for i in range(word_len):
        new_word = word[:i] + word[i + 1:]
        if new_word in dictionary:
            neighbors.append(new_word)

    return neighbors


def is_word_in_dictionary(word):
    """
    Check if the word exists in the dictionary. This is used to validate input words.

    Returns:
        bool: True if the word is in the dictionary, False otherwise.
    """
    return word in dictionary


def A_star(starting_word, goal_word, detail_output):
    # Initialize the frontier (open set) with the starting word
    frontier = []  # Use a heap queue for efficient selection of the node with the lowest f value
    heapq.heappush(frontier, (0 + heuristic(starting_word, goal_word), 0, starting_word, [starting_word]))

    # Set to track the explored words (closed set)
    explored = set()

    # Loop until there are no more nodes in the frontier
    while frontier:
        # Pop the word with the lowest f (f = g + h) from the frontier
        f, g, current_word, path = heapq.heappop(frontier)

        # If the current word is the goal word, return the transformation path
        if current_word == goal_word:
            if detail_output:
                for i, word in enumerate(path):
                    print(word)  # Print each word in the path
                    if i == 1:  # Print heuristic of the second word (for debugging)
                        print(f"Heuristic: {heuristic(word, goal_word)}")
            # print(f"Total cost: {g}")
            return path

        # Add the current word to the explored set (visited words)
        explored.add(current_word)

        # Explore neighbors (words that are one transformation away)
        for next_word in get_neighbors(current_word):
            if next_word in explored:
                continue  # Skip if this word has already been explored

            # Calculate the cost to move from current_word to next_word
            cost = calculate_cost(current_word, next_word)
            if cost == float('inf'):
                continue  # Skip invalid transformations (if the cost is infinity)

            # Calculate the new f score for the neighbor
            f_new = g + cost + heuristic(next_word, goal_word)  # f = g + h
            g_new = g + cost  # g is the cost from the start node

            # Add the neighbor to the frontier with the updated f, g, and path
            heapq.heappush(frontier, (f_new, g_new, next_word, path + [next_word]))

    # If no path is found, return a message indicating failure
    print("No path found")
    return


def hill_climbing(starting_word, goal_word, max_restarts, detail_output):
    """
    Hill Climbing Algorithm with restarts to find the least costly path between starting_word and goal_word.
    Restarts use neighbors of the original starting word.

    Args:
        starting_word (str): The word to start the transformation.
        goal_word (str): The word to reach through transformations.
        max_restarts (int): Number of times to restart the algorithm if stuck.
        detail_output (bool): Whether to output detailed information for debugging.

    Returns:
        list or str: The sequence of words forming the path, or "No path found".
    """
    best_path = None
    best_cost = float('inf')
    prev_starting_word = [None]  # Variable to track the starting word from the previous restart
    for restart in range(max_restarts):
        flag = 0
        current_word = starting_word
        path = [current_word]
        visited = set(prev_starting_word)  # Track first neighbors visited words
        # print(prev_starting_word)
        current_cost = 0

        # if detail_output:
        #     print(f"Restart {restart + 1}: Starting with {current_word}")

        while current_word != goal_word:
            neighbors = get_neighbors(current_word)

            if not neighbors:
                break  # No valid moves, stuck

            # Filter out neighbors that have already been visited
            neighbors = [neighbor for neighbor in neighbors if neighbor not in visited]

            if not neighbors:
                # print("No unvisited neighbors")
                break  # No unvisited neighbors, stuck

            # Evaluate all neighbors and select the one with the lowest cost
            best_neighbor = None
            best_neighbor_cost = float('inf')

            for neighbor in neighbors:
                cost = calculate_cost(current_word, neighbor)
                heuristic_cost = cost + heuristic(neighbor, goal_word)

                if heuristic_cost < best_neighbor_cost:
                    best_neighbor = neighbor
                    best_neighbor_cost = heuristic_cost
            if flag == 0:
                prev_starting_word.append(best_neighbor)
                flag = 1
            # Move to the best neighbor
            current_word = best_neighbor
            current_cost += calculate_cost(path[-1], current_word)
            path.append(current_word)
            visited.add(current_word)  # Mark the new word as visited

        if current_word == goal_word:
            best_path = path
            best_cost = current_cost

    if best_path:
        if detail_output:
            for i, word in enumerate(best_path):
                print(word)
                if i == 1:
                    print(f"Heuristic: {heuristic(word, goal_word)}")
            # print(f"Total cost: {best_cost}")
        else:
            for i, word in enumerate(best_path):
                print(word)
        return best_path
    else:
        print("No path found")
        return "No path found"


def simulated_annealing(starting_word, goal_word, detail_output, max_iterations=100, schedule=adaptive_schedule):
    """
    Simulated Annealing algorithm to find the shortest path between starting_word and goal_word.

    Args:
        starting_word (str): The word to start the transformation.
        goal_word (str): The word to reach through transformations.
        detail_output (bool): Whether to output detailed information for debugging.
        max_iterations (int): Maximum number of iterations to run the algorithm.
        schedule (function): A function to calculate temperature at step t (e.g., schedule_linear or adaptive_schedule).

    Returns:
        list or str: The sequence of words forming the path, or "No path found".
    """
    current_word = starting_word
    current_cost = heuristic(current_word, goal_word)
    # visited = set()  # Track visited words
    # visited.add(current_word)
    best_solution = [current_word]
    best_cost = current_cost
    flag = True
    actionsList=[]

    for t in range(max_iterations + 1):
        # Get the current temperature
        temperature = schedule(t, max_iterations)
        if temperature <= 0:
            break  # Stop if temperature reaches zero

        # Generate neighbors and exclude visited words
        neighbors = [word for word in get_neighbors(current_word)]
        if not neighbors:
            break  # No valid transformations, stuck

        # Select a neighbor randomly
        new_word = random.choice(neighbors)
        # visited.add(new_word)  # Mark as visited

        # Calculate the new cost
        new_cost = heuristic(new_word, goal_word)
        delta = new_cost - current_cost

        if detail_output and flag:
            # print("First step actions and probabilities:")
            prob = 1 if delta <= 0 else math.exp(-delta / temperature)
            actionsList.append(f"Actions: {new_word}, Delta: {delta}, Probability: {prob:.4f}")

        # Decide whether to accept the new solution
        if delta <= 0 or random.random() < math.exp(-delta / temperature):
            flag = False
            current_word = new_word
            current_cost = new_cost
            best_solution.append(current_word)

            # Update the best solution
            if new_cost < best_cost:
                best_cost = new_cost

        # if detail_output:
        #     print(f"Iteration {t + 1}: Current word: {current_word}, Temperature: {temperature:.2f}, Cost: {current_cost}")

        # Check if goal is reached
        if current_word == goal_word:
            print(best_solution[0])
            if detail_output:
                for action in actionsList:
                    print(action)
            for word in best_solution[1:]:
                print(word)
            return best_solution

    print("No path found")
    return "No path found"


def local_beam_search(starting_word, goal_word, beam_width, detail_output, max_iterations=10000):
    """
    Perform Local Beam Search to find the shortest transformation path between a starting word and the goal word.

    Args:
        starting_word (str): Initial word to start the search with.
        goal_word (str): The goal word to reach through transformations.
        beam_width (int): Number of beams to keep track of at each iteration.
        detail_output (bool): Whether to print detailed output for debugging.
        max_iterations (int): Maximum number of iterations to run the search.

    Returns:
        tuple: The goal word if reached and the path taken, or "No solution found" and an empty path if no solution exists.
    """
    beams = [starting_word]  # Initialize with the starting word
    visited = set(starting_word)  # Set to track visited words
    all_beams = [[starting_word]]  # Save all beams across iterations
    first_iteration = []

    for iteration in range(max_iterations):
        all_neighbors = []  # List to store all the neighbors of the current beams

        # Expand each beam
        for word in beams:
            neighbors = get_neighbors(word)  # Generate all valid neighbors

            # Filter out neighbors that have already been visited
            unvisited_neighbors = [neighbor for neighbor in neighbors if neighbor not in visited]

            all_neighbors.extend(unvisited_neighbors)  # Add unvisited neighbors to the list

        # Sort neighbors based on heuristic towards the goal word
        all_neighbors.sort(key=lambda neighbor: heuristic(neighbor, goal_word))

        # Keep the top 'beam_width' neighbors
        beams = all_neighbors[:beam_width]

        # Add chosen beams to the visited set
        visited.update(beams)

        # Save the beams for this iteration
        all_beams.append(beams)

        if detail_output and iteration == 0:
            # print(f"Iteration {iteration + 1}:")
            first_iteration = (f"  All neighbors: {all_neighbors}\n Current beams: {beams}")
            # print(f"  Current beams: {beams}")

        # Check if any beam has reached the goal
        if goal_word in beams:
            # Reconstruct the path
            path = [goal_word]
            current = goal_word
            all_beams=all_beams[:-1]

            for beam in reversed(all_beams):
                # Find the neighbor with the lowest heuristic from the beam
                valid_neighbors = [(word, heuristic(word, current)) for word in beam if word in get_neighbors(current)]
                if valid_neighbors:
                    best_neighbor = min(valid_neighbors, key=lambda x: x[1])[0]
                    path.append(best_neighbor)
                    current = best_neighbor

            path.reverse()
            print("\nPath to goal:")
            print(path[0])
            if detail_output:
                print(first_iteration)
            for i, word in enumerate(path[1:]):
                print(word)  # Print each word in the path
            return goal_word, path

    return "No solution found"


def next_generation(current_gen, goal):
    next_gen = []

    # Sort the current generation by their heuristic values (lower is better)
    sorted_gen = sorted(current_gen, key=lambda word: heuristic(word, goal))

    # Keep the two best individuals (parents)
    next_gen.extend(sorted_gen[:2])

    # Create children by modifying characters
    while len(next_gen) < len(current_gen):
        parent1, parent2 = random.sample(sorted_gen[:10], 2)  # Select two parents from the top 10

        # Child 1: Swap a random character in parent1 with the last character of parent2
        random_index1 = random.randint(0, len(parent1) - 1)
        child1 = list(parent1)
        child1[random_index1] = parent2[-1]
        child1 = ''.join(child1)

        # Child 2: Swap a random character in parent2 with the last character of parent1
        random_index2 = random.randint(0, len(parent2) - 1)
        child2 = list(parent2)
        child2[random_index2] = parent1[-1]
        child2 = ''.join(child2)

        # Check if the child is in the dictionary, if not, replace it with the closest valid word
        child1 = child1 if child1 in dictionary else mutate(child1, parent1)
        child2 = child2 if child2 in dictionary else mutate(child2, parent2)

        # Add the children to the next generation
        next_gen.append(child1)
        next_gen.append(child2)

    return next_gen


def mutate(word, parent):
    """
    Mutates the word to find a neighbor that is also a neighbor of the parent.
    If multiple such neighbors exist, choose one at random.
    If no such neighbor exists, return a random neighbor of the parent.
    """
    import random

    # Get neighbors of the word and the parent
    word_neighbors = get_neighbors(word)
    parent_neighbors = get_neighbors(parent)

    # Find common neighbors between the word and the parent
    common_neighbors = set(word_neighbors).intersection(parent_neighbors)

    if common_neighbors:
        # Choose a random neighbor from the common neighbors
        return random.choice(list(common_neighbors))

    # If no common neighbor exists, return a random neighbor of the parent
    if parent_neighbors:
        return random.choice(parent_neighbors)

    # If no valid mutation is found, return the original word
    return word


def generate_path_in_order(start_word, goal_word, generations_data):
    """
    Generate a path from the start_word to the goal_word using one word from each generation in order.

    Args:
        start_word (str): The starting word.
        goal_word (str): The goal word.
        generations_data (list of lists): A list of generations, each containing words.

    Returns:
        list: A list of words representing the path from start_word to goal_word in generation order.
    """
    path = [start_word]  # Initialize the path with the starting word

    for generation in generations_data:
        last_word = path[-1]
        # Find neighbors of the last word in the current generation
        neighbors = [word for word in generation if word in get_neighbors(last_word)]

        if not neighbors:
            # print("No valid neighbors found in this generation. Path construction terminated.")
            break

        # Choose the neighbor with the lowest heuristic to the goal word
        next_word = min(neighbors, key=lambda word: heuristic(word, goal_word))
        path.append(next_word)

        # Stop if the goal word is found
        if next_word == goal_word:
            break

    return path


def genetic_algorithm(start_word, goal_word, detail_output, generations=100):
    """
    Run the genetic algorithm to evolve words from start_word to goal_word.

    Args:
        start_word (str): The starting word.
        goal_word (str): The goal word.
        detail_output (bool): If True, print details of each generation.
        generations (int): The number of generations to evolve.

    Returns:
        None
    """
    current_gen = sorted(get_neighbors(start_word), key=lambda word: heuristic(word, goal_word))[:10]
    generations_data = [current_gen]  # Store all generations for path construction
    generation1 = None

    # if detail_output:
    #     print(f"Generation 0: {current_gen}")

    for generation in range(1, generations + 1):
        if detail_output and generation == 2:
            generation1 = f"Generation 1: {current_gen}"
        if goal_word in current_gen:
            # print(f"Goal word '{goal_word}' found in generation {generation - 1}.")
            break

        current_gen = next_generation(current_gen, goal_word)
        generations_data.append(current_gen)

        # if detail_output:
        #     print(f"Generation {generation}: {current_gen}")

        if goal_word in current_gen:
            # print(f"Goal word '{goal_word}' found in generation {generation}.")
            break

    # Generate and print the path
    path = generate_path_in_order(start_word, goal_word, generations_data)
    if goal_word not in path:
        print(f"No path found")
    else:
        print("\nPath from start to goal:")
        print(path[0])
        print(path[1])
        if detail_output and generation1 != None:
            print(generation1)
        if path.__len__()>2:
            for word in path[2:]:
                print(word)


# Main code to check if both starting and goal words are in the dictionary
find_word_path("dog", "cat", 5, True)