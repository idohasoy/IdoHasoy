import csv
from math import log2
import random
from scipy.stats import chi2

# Global variables
headers = []
data = []
thresholds = {}
flag = True
# Load the dataset
def load_data(file_path):
    """Load the data from a CSV file."""
    with open(file_path, 'r') as file:
        reader = csv.reader(file, delimiter=',')
        data = [row for row in reader]
    headers = data[0]
    rows = data[1:]
    return headers, rows


# Determine threshold for splitting numerical attributes
def calculate_thresholds(headers, data):
    """Calculate thresholds for numerical attributes."""
    thresholds = {}
    for i, header in enumerate(headers):
        try:
            values = [float(row[i]) for row in data]
            thresholds[header] = sum(values) / len(values)  # Mean as threshold
        except ValueError:
            thresholds[header] = None  # Non-numerical attribute
    return thresholds


# Group data based on thresholds
def group_data_by_thresholds(headers, data, thresholds):
    """Split attributes into groups based on calculated thresholds and custom rules."""
    grouped_data = []
    for row in data:
        new_row = []
        for i, value in enumerate(row):
            if headers[i] == 'age':  # Custom bucketing for 'age'
                age = float(value)
                if age <= 15:
                    new_row.append('0-15')
                elif age <= 21:
                    new_row.append('15-21')
                elif age <= 66:
                    new_row.append('21-66')
                else:
                    new_row.append('66+')
            elif headers[i] == 'balance':  # Custom bucketing for 'balance'
                balance = float(value)
                if balance < 0:
                    new_row.append('Group 1')
                elif balance < 500:
                    new_row.append('Group 2')
                elif balance < 2000:
                    new_row.append('Group 3')
                else:
                    new_row.append('Group 4')
            elif headers[i] == 'day':  # Custom bucketing for 'day'
                day = int(value)
                if 1 <= day <= 10:
                    new_row.append('Early Month (1-10)')
                elif 11 <= day <= 20:
                    new_row.append('Mid Month (11-20)')
                else:
                    new_row.append('Late Month (21-31)')
            elif headers[i] == 'month':  # Custom bucketing for 'month'
                if value in ['dec', 'jan', 'feb']:
                    new_row.append('Winter')
                elif value in ['mar', 'apr', 'may']:
                    new_row.append('Spring')
                elif value in ['jun', 'jul', 'aug']:
                    new_row.append('Summer')
                else:  # ['sep', 'oct', 'nov']
                    new_row.append('Fall')
            elif headers[i] == 'job':  # Custom bucketing for 'job'
                if value in ['admin', 'management', 'entrepreneur', 'self-employed']:
                    new_row.append('Group 1')
                elif value in ['retired', 'unemployed']:
                    new_row.append('Group 2')
                elif value in ['services', 'technician', 'blue-collar', 'housemaid', 'student']:
                    new_row.append('Group 3')
                elif value == 'unknown':
                    new_row.append('Group 4')
                else:
                    new_row.append('Other')  # For any unexpected values
            elif headers[i] == 'campaign':  # Custom bucketing for 'campaign'
                campaign = int(value)
                if campaign == 1:
                    new_row.append('Group 1')
                elif 2 <= campaign <= 4:
                    new_row.append('Group 2')
                else:
                    new_row.append('Group 3')
            elif headers[i] == 'pdays':  # Custom bucketing for 'pdays'
                pdays = int(value)
                if pdays == -1:
                    new_row.append('Group 1')
                elif 1 <= pdays <= 183:
                    new_row.append('Group 2')
                elif 184 <= pdays <= 365:
                    new_row.append('Group 3')
                else:  # pdays > 365
                    new_row.append('Group 4')
            elif headers[i] == 'previous':  # Custom bucketing for 'previous'
                previous = int(value)
                if previous == 0:
                    new_row.append('Group 1')
                elif 1 <= previous <= 2:
                    new_row.append('Group 2')
                else:  # previous >= 3
                    new_row.append('Group 3')
            elif thresholds[headers[i]] is not None:  # Numeric attributes
                # Default behavior for other numeric attributes
                new_row.append('Group 1' if float(value) <= thresholds[headers[i]] else 'Group 2')
            else:
                new_row.append(value)  # Non-numeric attributes remain unchanged
        grouped_data.append(new_row)
    return grouped_data


# Calculate entropy
def calculate_entropy(values):
    """Calculate entropy for a list of values."""
    total = len(values)
    if total == 0:
        return 0
    counts = {}
    for value in values:
        counts[value] = counts.get(value, 0) + 1
    entropy = -sum((count / total) * log2(count / total) for count in counts.values() if count > 0)
    return entropy


# Calculate information gain
def information_gain(data, attribute_index, target_index):
    """Calculate information gain for a split on a specific attribute."""
    total_entropy = calculate_entropy([row[target_index] for row in data])
    values = {}
    for row in data:
        key = row[attribute_index]
        if key not in values:
            values[key] = []
        values[key].append(row[target_index])
    weighted_entropy = sum((len(subset) / len(data)) * calculate_entropy(subset) for subset in values.values())
    return total_entropy - weighted_entropy


# Perform chi-squared test
def chi_squared_test(data, attribute_index, target_index):
    """Perform chi-squared test for a split."""
    observed = {}
    target_values = set(row[target_index] for row in data)
    attribute_values = set(row[attribute_index] for row in data)

    for attr_val in attribute_values:
        observed[attr_val] = {target: 0 for target in target_values}
        for row in data:
            if row[attribute_index] == attr_val:
                observed[attr_val][row[target_index]] += 1

    total_counts = {target: sum(observed[attr_val][target] for attr_val in attribute_values) for target in target_values}
    total = len(data)
    chi2_stat = 0

    for attr_val in attribute_values:
        attr_total = sum(observed[attr_val].values())
        for target in target_values:
            expected = (attr_total * total_counts[target]) / total
            if expected > 0:
                chi2_stat += ((observed[attr_val][target] - expected) ** 2) / expected

    return chi2_stat, len(attribute_values) - 1


# Prune the decision tree
def prune_tree(tree, data, headers, target_index, confidence_level=0.95):
    """Prune the tree using the chi-squared test."""

    def prune_recursive(node, sub_data):
        if not isinstance(node, dict):
            return node

        attribute = next(iter(node))
        attr_index = headers.index(attribute)

        # Recursively prune child nodes
        for value in list(node[attribute]):
            subset = [row for row in sub_data if row[attr_index] == value]
            node[attribute][value] = prune_recursive(node[attribute][value], subset)

        # Perform chi-squared test to decide if this node should be pruned
        chi2_stat, dof = chi_squared_test(sub_data, attr_index, target_index)
        critical_value = chi2.ppf(confidence_level, dof)

        if chi2_stat < critical_value:
            # Prune the node and replace it with the majority class
            target_values = [row[target_index] for row in sub_data]
            return max(set(target_values), key=target_values.count)

        return node

    return prune_recursive(tree, data)


# Build the decision tree
def build_tree(ratio):
    """Build the decision tree."""
    random.shuffle(data)
    split_index = int(len(data) * ratio)
    train_data = data[:split_index]
    val_data = data[split_index:]

    def recursive_tree(sub_data, available_attributes):
        """Recursively build the decision tree."""
        target_values = [row[target_index] for row in sub_data]

        # If all target values are the same, return that value
        if len(set(target_values)) == 1:
            return target_values[0]

        # If no attributes are left, return the majority target value
        if not available_attributes:
            return max(set(target_values), key=target_values.count)

        # Find the best attribute to split on
        best_gain = -1
        best_attr = None
        for attr in available_attributes:
            gain = information_gain(sub_data, attr, target_index)
            if gain > best_gain:
                best_gain = gain
                best_attr = attr

        # If no attribute provides gain, return majority target value
        if best_attr is None:
            return max(set(target_values), key=target_values.count)

        # Create a new branch in the tree
        tree = {headers[best_attr]: {}}
        available_attributes = [a for a in available_attributes if a != best_attr]

        # Split data based on the selected attribute
        split_values = {}
        for row in sub_data:
            key = row[best_attr]
            if key not in split_values:
                split_values[key] = []
            split_values[key].append(row)

        # Recursively create subtrees for each split
        for value, subset in split_values.items():
            tree[headers[best_attr]][value] = recursive_tree(subset, available_attributes)

        return tree

    # Start recursive tree building
    available_attributes = [i for i in range(len(headers)) if i != target_index]
    tree = recursive_tree(train_data, available_attributes)

    # Prune the tree using chi-squared test
    pruned_tree = prune_tree(tree, train_data, headers, target_index)

    # Validate the pruned tree if validation set is not empty
    if val_data:
        val_error = validate_tree(pruned_tree, val_data, headers, target_index)
        print("Validation Error after Pruning:", val_error)

    if flag:
        display_tree(pruned_tree)
    return pruned_tree


# Validate the decision tree
def validate_tree(tree, data, headers, target_index):
    """Calculate validation error for the decision tree."""
    errors = 0
    for row in data:
        prediction = predict(tree, row, headers)
        if prediction != row[target_index]:
            errors += 1
    return errors / len(data)


# Predict using the tree
def predict(tree, row, headers):
    """
    Make a prediction for a single row using the decision tree.

    Args:
        tree (dict): The decision tree.
        row (list): The input row to predict.
        headers (list): The list of attribute names.

    Returns:
        str: The predicted class.
    """
    while isinstance(tree, dict):
        attribute = next(iter(tree))  # Get the current splitting attribute
        attr_index = headers.index(attribute)  # Find the index of the attribute in the headers
        value = row[attr_index]  # Get the value of the attribute for the given row

        if value in tree[attribute]:
            # If the value exists in the current attribute's branches, follow that branch
            tree = tree[attribute][value]
        else:
            # Handle unseen values by returning the majority answer from the current attribute's branches
            # print(f"Unknown value encountered: {value} for attribute {attribute}. Calculating majority prediction.")
            return calculate_majority(tree[attribute])

    return tree  # Return the leaf value when reached


def calculate_majority(branches):
    """
    Calculate the majority prediction from a dictionary of branches.

    Args:
        branches (dict): The branches of the current attribute.

    Returns:
        str: The majority prediction.
    """
    counts = {}

    def count_leaf_values(subtree):
        if isinstance(subtree, dict):
            for value in subtree.values():
                count_leaf_values(value)
        else:
            counts[subtree] = counts.get(subtree, 0) + 1

    count_leaf_values(branches)

    # Return the value with the highest count (majority prediction)
    majority_prediction = max(counts, key=counts.get)
    # print(f"Majority prediction for unseen value: {majority_prediction}")
    return majority_prediction


# Display the decision tree
def display_tree(tree, path="Root"):
    """
    Print the decision tree in a tabular-like structure with paths.

    Args:
        tree (dict): The decision tree.
        path (str): The path to the current node.
    """
    if not isinstance(tree, dict):
        # Print the leaf node with its full path
        print(f"{path} -> Decision: {tree}")
        return

    for key, subtree in tree.items():
        # Iterate through the current tree level
        for value, child in subtree.items():
            # Build the path recursively
            new_path = f"{path} -> {key} = {value}"
            display_tree(child, new_path)


def transform_row(headers, row, thresholds):
    """
    Transform a single row of input data to align with the decision tree's expectations.

    Args:
        headers (list): List of dataset column headers.
        row (list): A single row of input data.
        thresholds (dict): Precomputed thresholds for numeric attributes.

    Returns:
        list: Transformed row ready for prediction.
    """
    transformed_row = []

    for i, value in enumerate(row):
        header = headers[i]

        # Apply transformation based on attribute
        if header == 'age':  # Custom bucketing for 'age'
            age = float(value)
            if age <= 15:
                transformed_row.append('0-15')
            elif age <= 21:
                transformed_row.append('15-21')
            elif age <= 66:
                transformed_row.append('21-66')
            else:
                transformed_row.append('66+')
        elif header == 'balance':  # Custom bucketing for 'balance'
            balance = float(value)
            if balance < 0:
                transformed_row.append('Group 1')
            elif balance < 500:
                transformed_row.append('Group 2')
            elif balance < 2000:
                transformed_row.append('Group 3')
            else:
                transformed_row.append('Group 4')
        elif header == 'day':  # Custom bucketing for 'day'
            day = int(value)
            if 1 <= day <= 10:
                transformed_row.append('Early Month (1-10)')
            elif 11 <= day <= 20:
                transformed_row.append('Mid Month (11-20)')
            else:
                transformed_row.append('Late Month (21-31)')
        elif header == 'month':  # Custom bucketing for 'month'
            if value in ['dec', 'jan', 'feb']:
                transformed_row.append('Winter')
            elif value in ['mar', 'apr', 'may']:
                transformed_row.append('Spring')
            elif value in ['jun', 'jul', 'aug']:
                transformed_row.append('Summer')
            else:  # ['sep', 'oct', 'nov']
                transformed_row.append('Fall')
        elif header == 'job':  # Custom bucketing for 'job'
            if value in ['admin', 'management', 'entrepreneur', 'self-employed']:
                transformed_row.append('Group 1')
            elif value in ['retired', 'unemployed']:
                transformed_row.append('Group 2')
            elif value in ['services', 'technician', 'blue-collar', 'housemaid', 'student']:
                transformed_row.append('Group 3')
            elif value == 'unknown':
                transformed_row.append('Group 4')
            else:
                transformed_row.append('Other')  # For any unexpected values
        elif header == 'campaign':  # Custom bucketing for 'campaign'
            campaign = int(value)
            if campaign == 1:
                transformed_row.append('Group 1')
            elif 2 <= campaign <= 4:
                transformed_row.append('Group 2')
            else:
                transformed_row.append('Group 3')
        elif header == 'pdays':  # Custom bucketing for 'pdays'
            pdays = int(value)
            if pdays == -1:
                transformed_row.append('Group 1')
            elif 1 <= pdays <= 183:
                transformed_row.append('Group 2')
            elif 184 <= pdays <= 365:
                transformed_row.append('Group 3')
            else:  # pdays > 365
                transformed_row.append('Group 4')
        elif header == 'previous':  # Custom bucketing for 'previous'
            previous = int(value)
            if previous == 0:
                transformed_row.append('Group 1')
            elif 1 <= previous <= 2:
                transformed_row.append('Group 2')
            else:  # previous >= 3
                transformed_row.append('Group 3')
        elif thresholds[header] is not None:  # Generic numerical attributes
            transformed_row.append('Group 1' if float(value) <= thresholds[header] else 'Group 2')
        else:  # Non-numerical attributes remain unchanged
            transformed_row.append(value)

    return transformed_row


def will_open_deposit(row_input):
    """
    Predict whether a customer will open a term deposit based on the decision tree.

    Args:
        row_input (list): A list of attribute values for a single customer, in the same order as the dataset
                          (excluding the target column).

    Returns:
        int: 1 if the customer is predicted to open a term deposit, 0 otherwise.
    """
    global flag
    # Transform input data using the same thresholds and grouping logic
    transformed_row = transform_row(headers[:-1], row_input, thresholds)  # Exclude target column from headers
    flag = False
    tree=build_tree(1.0)
    flag = True


    # Predict the outcome for the given row
    prediction = predict(tree,transformed_row, headers[:-1])  # Exclude the target column from headers

    # Convert the prediction to binary output
    if prediction == 'yes':  # Assuming 'yes' indicates the customer will open a term deposit
        print(1)
        return 1
    elif prediction == 'no':  # Assuming 'no' indicates the customer will not open a term deposit
        print(0)
        return 0
    else:
        print(f"Unexpected prediction value: {prediction}. Returning default value 0.")
        return 0


def tree_error(k):
    """
    Perform k-fold cross-validation to evaluate the decision tree's average error.

    Args:
        k (int): The number of folds for cross-validation.

    Returns:
        float: The average error rate across all folds.
    """
    global data , flag  # Declare `data` as global to allow modifications
    if k <= 1:
        raise ValueError("k must be greater than 1 for k-fold cross-validation.")

    # Shuffle the global data to randomize fold splits
    shuffled_data = data.copy()
    random.shuffle(shuffled_data)

    # Split data into k approximately equal folds
    fold_size = len(shuffled_data) // k
    folds = [shuffled_data[i * fold_size: (i + 1) * fold_size] for i in range(k)]
    if len(shuffled_data) % k != 0:  # Add remaining data to the last fold
        folds[-1].extend(shuffled_data[k * fold_size:])

    errors = []

    # Perform k-fold cross-validation
    for i in range(k):
        # Prepare training and validation sets
        validation_set = folds[i]
        training_set = [row for j, fold in enumerate(folds) if j != i for row in fold]

        # Temporarily reassign `data` to the training set for tree building
        data = training_set
        flag = False
        current_tree = build_tree(ratio=1.0)
        flag=True

        # Evaluate the tree on the validation set
        fold_error = validate_tree(current_tree, validation_set, headers, target_index)
        errors.append(fold_error)

    # Reset the global `data` variable to its original state
    data = shuffled_data

    # Calculate the average error rate
    average_error = sum(errors) / k
    print(f"Average error rate over {k} folds: {average_error:.4f}")
    return average_error


# Load and preprocess the dataset
headers, data = load_data('bank.csv')
thresholds = calculate_thresholds(headers, data)
data = group_data_by_thresholds(headers, data, thresholds)

target_column = 'y'  # Adjust to match the actual column name in the dataset
target_index = headers.index(target_column)

build_tree(0.6)